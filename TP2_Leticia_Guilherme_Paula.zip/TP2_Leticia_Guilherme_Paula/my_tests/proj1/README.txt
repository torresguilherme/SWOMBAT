Comandos do terminal usados para rodar o teste

A saída é saida.hex, mas o arquivo proj1.hex é identico, mudamos o nome para atender a especificacao.

./mont teste1.a teste1.o
./mont max1.a max1.o
./mont med1.a med1.o
./mont min1.a min1.o
./mont prod1.a prod1.o
./mont sum1.a sum1.o
./link teste1.o max1.o med1.o min1.o prod1.o sum1.o
