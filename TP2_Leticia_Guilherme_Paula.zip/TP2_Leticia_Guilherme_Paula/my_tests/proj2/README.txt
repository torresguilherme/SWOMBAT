Comandos do terminal usados para rodar o teste

A saída é saida.hex, mas o arquivo proj2.hex é identico, mudamos o nome para atender a especificacao.

./mont teste2.a teste2.o
./mont max2.a max2.o
./mont med2.a med2.o
./mont min2.a min2.o
./mont prod2.a prod2.o
./mont sum2.a sum2.o
./link teste2.o max2.o med2.o min2.o prod2.o sum2.o
